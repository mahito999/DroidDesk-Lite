package com.droiddesk.lite;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;

public class BrowserActivity extends Activity {
    private WebView web;
    private EditText address;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.rgb(16,21,31));
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.WHITE);
        LinearLayout bar = new LinearLayout(this);
        bar.setPadding(10, 10, 10, 10);
        bar.setBackgroundColor(Color.rgb(16,21,31));
        address = new EditText(this);
        address.setSingleLine(true);
        address.setTextColor(Color.WHITE);
        address.setHintTextColor(Color.LTGRAY);
        address.setHint("Enter website or search");
        address.setText("https://www.google.com");
        address.setImeOptions(EditorInfo.IME_ACTION_GO);
        bar.addView(address, new LinearLayout.LayoutParams(0, dp(48), 1));
        Button go = new Button(this);
        go.setText("Go");
        bar.addView(go, new LinearLayout.LayoutParams(dp(64), dp(48)));
        root.addView(bar);
        web = new WebView(this);
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true);
        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new WebChromeClient());
        root.addView(web, new LinearLayout.LayoutParams(-1, 0, 1));
        go.setOnClickListener(v -> loadAddress());
        address.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_GO || actionId == EditorInfo.IME_ACTION_DONE) { loadAddress(); return true; }
            return false;
        });
        setContentView(root);
        web.loadUrl("https://www.google.com");
    }

    private void loadAddress() {
        String value = address.getText().toString().trim();
        if (value.isEmpty()) return;
        if (!value.contains(".") || value.contains(" ")) value = "https://www.google.com/search?q=" + android.net.Uri.encode(value);
        else if (!value.matches("(?i)^https?://.*")) value = "https://" + value;
        web.loadUrl(value);
    }

    @Override public void onBackPressed() {
        if (web != null && web.canGoBack()) web.goBack(); else super.onBackPressed();
    }
    @Override protected void onDestroy() { if (web != null) web.destroy(); super.onDestroy(); }
    private int dp(int value) { return (int)(value * getResources().getDisplayMetrics().density + 0.5f); }
}
