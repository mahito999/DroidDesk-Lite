package com.droiddesk.lite;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

public class MainActivity extends Activity {
    private final int bg = Color.rgb(16, 21, 31);
    private final int panel = Color.rgb(27, 35, 49);
    private final int mint = Color.rgb(99, 230, 190);
    private final int white = Color.rgb(240, 244, 250);
    private final int muted = Color.rgb(166, 179, 199);

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(bg);
        getWindow().setNavigationBarColor(bg);
        buildHome();
    }

    private void buildHome() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(22), dp(24), dp(22), dp(28));
        root.setBackgroundColor(bg);
        scroll.addView(root);

        TextView brand = text("DROIDDESK", 13, mint, true);
        brand.setLetterSpacing(0.16f);
        root.addView(brand);
        TextView title = text("Your pocket\ncomputer hub.", 31, white, true);
        title.setPadding(0, dp(12), 0, dp(8));
        root.addView(title);
        root.addView(text("A lightweight launcher for your browser and future virtual systems.", 15, muted, false));

        LinearLayout status = card(root);
        status.addView(text("PROJECT STATUS", 11, mint, true));
        status.addView(text("Starter build · Internet browser ready", 16, white, true), paramsTop(8));
        status.addView(text("Android 7 guest and PC game runtime are not included yet.", 13, muted, false), paramsTop(6));

        section(root, "WORKSPACES");
        addAction(root, "🌐  Web browser", "Open websites inside DroidDesk", "OPEN BROWSER", v -> startActivity(new Intent(this, BrowserActivity.class)));
        addAction(root, "🤖  Android 7.1.2", "Guest-system launcher placeholder", "VIEW STATUS", v -> showInfo("Android 7.1.2", "The virtual-machine engine and a compatible Android 7 system image must be integrated before this can boot a guest OS."));
        addAction(root, "🖥️  PC mode", "Desktop and compatible PC games", "VIEW STATUS", v -> showInfo("PC mode", "A PC emulator or compatibility layer is not bundled in this starter. Minecraft and other games require a compatible runtime, legal game files, and suitable graphics support."));

        section(root, "DEVICE CHECKLIST");
        LinearLayout checklist = card(root);
        checklist.addView(text("✓  App shell and navigation", 14, white, false));
        checklist.addView(text("✓  Embedded browser with internet permission", 14, white, false), paramsTop(8));
        checklist.addView(text("○  Android 7 guest engine", 14, muted, false), paramsTop(8));
        checklist.addView(text("○  PC emulator / game compatibility", 14, muted, false), paramsTop(8));

        TextView footer = text("DroidDesk Lite · 0.1.0-alpha", 12, muted, false);
        footer.setGravity(Gravity.CENTER);
        footer.setPadding(0, dp(22), 0, 0);
        root.addView(footer);
        setContentView(scroll);
    }

    private void section(LinearLayout root, String name) {
        TextView label = text(name, 12, muted, true);
        label.setLetterSpacing(0.12f);
        label.setPadding(0, dp(24), 0, dp(10));
        root.addView(label);
    }

    private void addAction(LinearLayout root, String title, String subtitle, String buttonLabel, View.OnClickListener action) {
        LinearLayout box = card(root);
        box.addView(text(title, 18, white, true));
        box.addView(text(subtitle, 13, muted, false), paramsTop(5));
        Button button = new Button(this);
        button.setText(buttonLabel);
        button.setTextColor(bg);
        button.setAllCaps(false);
        button.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        button.setBackground(round(mint, 12));
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(-1, dp(46));
        bp.topMargin = dp(14);
        box.addView(button, bp);
        button.setOnClickListener(action);
    }

    private LinearLayout card(LinearLayout parent) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(16), dp(16), dp(16), dp(16));
        box.setBackground(round(panel, 18));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.topMargin = dp(14);
        parent.addView(box, p);
        return box;
    }

    private TextView text(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(size);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private GradientDrawable round(int color, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radius));
        return d;
    }

    private LinearLayout.LayoutParams paramsTop(int top) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.topMargin = dp(top);
        return p;
    }

    private int dp(int value) { return (int)(value * getResources().getDisplayMetrics().density + 0.5f); }

    private void showInfo(String title, String message) {
        new android.app.AlertDialog.Builder(this)
            .setTitle(title)
            .setMessage(message)
            .setPositiveButton("Got it", null)
            .show();
    }
}
