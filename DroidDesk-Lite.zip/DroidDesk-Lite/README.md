# DroidDesk Lite

A small Android starter project for a future Android 7 guest + PC workspace app. It currently includes a dashboard and a functional embedded web browser.

## Included today
- Android app shell and workspace dashboard
- Embedded WebView browser with address/search field
- GitHub Actions workflow that builds and uploads a debug APK
- Minimum host Android version: Android 8.0 (API 26)

## Not included yet
- Android 7.1.2 virtual-machine engine or bootable system image
- Root integration for a guest OS
- PC/Windows emulator, GPU acceleration, or PC game runtime
- Minecraft files or game-license bypasses

Those features require a compatible VM/emulator engine, legally obtained system/game files, device-specific testing, and significant additional work. The buttons in this starter intentionally show status dialogs rather than pretending the virtual systems already work.

## Build APK on GitHub using a phone
1. Create a new GitHub repository.
2. Upload the contents of this folder (not the ZIP file itself) to the repository root.
3. Open **Actions** and enable workflows if GitHub asks.
4. Run **Build DroidDesk Lite APK** with **Run workflow**, or push a commit to `main`.
5. Open the completed workflow run and download the `DroidDeskLite-debug-apk` artifact. Extract it to get `app-debug.apk`.

## Local build
Install JDK 17 and Android SDK platform 35, then run:

```bash
./gradlew assembleDebug
```

Output: `app/build/outputs/apk/debug/app-debug.apk`.
